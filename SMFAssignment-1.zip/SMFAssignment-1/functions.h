//Sadam Farah
//CS303
//Assignment 1
//9-20-2022


int** read_numbers();
int* search_number(int** numbers);
int* replace_number(int** numbers, int row, int col);
int** add_number(int** numbers);
int** delete_number(int** numbers, int row, int col);

